package test;
public interface DBInfo
{
public static final String
dbURL="jdbc:oracle:thin:@localhost:1522:xe";
public static final String dbUName="Avanish";
public static final String dbPWord="vishal";
}